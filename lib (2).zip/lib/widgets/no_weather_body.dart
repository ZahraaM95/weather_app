import 'package:flutter/material.dart';

import 'search_view.dart';

class NoWeatherBody extends StatelessWidget {
  const NoWeatherBody({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
              appBar: AppBar(
          title: const Text('Weather App'),
          actions: [IconButton(onPressed: (){
      
            Navigator.of(context).push(MaterialPageRoute(builder: (context){
              return const SearchView();
            }));
          },
           icon: const Icon(Icons.search))],
        ),
      body:const  Padding(
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'there is no weather 😔 start',
                style: TextStyle(
                  fontSize: 30,
                ),
              ),
              Text(
                'searching now 🔍',
                style: TextStyle(
                  fontSize: 30,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
